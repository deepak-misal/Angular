export interface IBall{
    index:number,
    color:string
}